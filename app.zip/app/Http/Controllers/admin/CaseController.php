<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\CaseRequest;
use App\Models\Brand;
use App\Models\CaseManagement;
use App\Models\Company;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Routing\Controllers\HasMiddleware;
use Illuminate\Routing\Controllers\Middleware;

class CaseController extends Controller implements HasMiddleware
{
    public static function middleware(): array
    {
        return [

            // new Middleware('permission:case management', only: ['caseIndex']),
            // new Middleware('permission:case management', only: ['caseCreate']),
            // new Middleware('permission:case management', only: ['caseDestroy']),
            // new Middleware('permission:case management', only: ['caseEdit']),

            new Middleware('permission:view case management', only: ['caseIndex']),
            new Middleware('permission:create case management', only: ['caseCreate']),
            new Middleware('permission:edit case management', only: ['caseEdit']),
            new Middleware('permission:delete case management', only: ['caseDestroy']),
        ];
    }

    public function caseIndex(){
        $cases = CaseManagement::with('product', 'company')->orderBy('id', 'desc')->get();
        return view('admin.case.index', compact('cases'));
    }

    public function caseCreate()
    {
        $companies = Company::all();
        $brands = Brand::all();
        $products = Product::all();
        return view('admin.case.create', compact('companies', 'brands', 'products'));
    }


    public function caseStore(CaseRequest $request)
    {
        $case = new CaseManagement();
        $case->auto_id = $request->auto_id;
        $case->client_id = $request->client_id;
        $case->case_name = $request->case_name;
        $case->case_type = $request->case_type;
        $case->target_category = $request->target_category;
        $case->case_priority = $request->case_priority;
        $case->case_fee = $request->case_fee;
        $case->task = $request->task;
        $case->flag = $request->flag;
        $case->case_location = $request->case_location;
        $case->start_date = $request->start_date;
        $case->end_date = $request->end_date;
        $case->status = $request->status;
        $case->description = $request->description;
        $case->company_id = $request->company_id;
        $case->brand_id = $request->brand_id;
        $case->product_id = $request->product_id;

        if ($request->hasFile('document')) {
            $file = $request->file('document');
            $filename = date('dmy') . '_document_' . '.' . $file->getClientOriginalExtension();
            $path = $file->storeAs('Case', $filename, 'public');
            $case->document = $path;
        }
        $case->save();

        return to_route('case.index')->with('success', 'Case Added Successfully');
    }


    public function caseEdit($id)
    {
        $case = CaseManagement::find($id);
        $companies = Company::all();
        $brands = Brand::all();
        $products = Product::all();
        return view('admin.case.edit', compact('companies', 'brands', 'case', 'products'));
    }


    public function caseUpdate(CaseRequest $request, $id)
    {
        $case = CaseManagement::find($id);

        // $case->auto_id = $request->auto_id;
        $case->client_id = $request->client_id;
        $case->case_name = $request->case_name;
        $case->case_type = $request->case_type;
        $case->target_category = $request->target_category;
        $case->case_priority = $request->case_priority;
        $case->case_fee = $request->case_fee;
        $case->task = $request->task;
        $case->flag = $request->flag;
        $case->case_location = $request->case_location;
        $case->start_date = $request->start_date;
        $case->end_date = $request->end_date;
        $case->status = $request->status;
        $case->description = $request->description;
        $case->company_id = $request->company_id;
        $case->brand_id = $request->brand_id;
        $case->product_id = $request->product_id;

        if ($request->hasFile('document')) {
            $file = $request->file('document');
            $filename = date('dmy') . '_document_' . '.' . $file->getClientOriginalExtension();
            $path = $file->storeAs('Case', $filename, 'public');
            $case->document = $path;
        }
        $case->update();

        return to_route('case.index')->with('success', 'Case Updated Successfully');
    }



    public function caseDestroy($id)
    {
        // dd($id);
        $case = CaseManagement::find($id);
        $case->delete();
        return to_route('case.index')->with('success', 'Case Deleted Successfully');
    }


    public function getCaseData($id)
    {
        $case = CaseManagement::with('product', 'company', 'brand')->find($id);
        if ($case) {
            return response()->json([
                'case_type' => $case->case_type,
                'brand_id' => $case->brand->brand_name,
                'product_id' => $case->product->product_name,
                'company_id' => $case->company->company_name,
            ]);
        } else {
            return response()->json([
                'case_type' => '',
                'brand_id' => '',
                'product_id' => '',
                'company_id' => '',
            ]);
        }
    }
}
