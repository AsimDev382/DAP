<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class adminPermissionController extends Controller
{

}
