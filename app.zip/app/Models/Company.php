<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Company extends Model
{
    protected $table = 'companies';

    public function brands()
    {
        return $this->hasMany(Brand::class);
    }
    public function user()
    {
        return $this->hasMany(User::class);
    }
    public function product()
    {
        return $this->hasMany(Product::class);
    }
    public function investigation()
    {
        return $this->hasMany(Investigation::class);
    }
    public function case()
    {
        return $this->hasMany(CaseManagement::class);
    }
    public function department()
    {
        return $this->hasMany(Department::class);
    }
}
