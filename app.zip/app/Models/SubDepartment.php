<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SubDepartment extends Model
{
    public function department()
    {
        return $this->hasMany(Department::class);
    }
}
